package com.tugas.pemrogramanmobile

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.ArrayAdapter
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.tugas.pemrogramanmobile.databinding.ActivitySpinnerDialogBinding
import java.util.Calendar

class SpinnerDialogActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySpinnerDialogBinding

    // Data negara dan kota
    private val negaraList = arrayOf("Indonesia", "Malaysia", "Singapura", "Jepang", "Korea Selatan")

    private val kotaMap = mapOf(
        "Indonesia" to arrayOf("Jakarta", "Bandung", "Surabaya", "Yogyakarta", "Bali"),
        "Malaysia" to arrayOf("Kuala Lumpur", "Penang", "Johor Bahru"),
        "Singapura" to arrayOf("Singapore City", "Jurong East", "Woodlands"),
        "Jepang" to arrayOf("Tokyo", "Osaka", "Kyoto", "Hiroshima"),
        "Korea Selatan" to arrayOf("Seoul", "Busan", "Incheon", "Daegu")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySpinnerDialogBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { finish() }

        setupSpinners()
        setupDialogs()
    }

    private fun setupSpinners() {
        // Spinner Negara
        val negaraAdapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, negaraList)
        binding.actvNegara.setAdapter(negaraAdapter)

        binding.actvNegara.setOnItemClickListener { _, _, position, _ ->
            val negara = negaraList[position]
            updateKotaSpinner(negara)
        }

        // Set default kota kosong
        binding.actvKota.setText("")
    }

    private fun updateKotaSpinner(negara: String) {
        val kotaList = kotaMap[negara] ?: arrayOf()
        val kotaAdapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, kotaList)
        binding.actvKota.setAdapter(kotaAdapter)
        binding.actvKota.setText("")
    }

    private fun setupDialogs() {
        // DatePickerDialog
        binding.btnDatePicker.setOnClickListener {
            val calendar = Calendar.getInstance()
            DatePickerDialog(
                this,
                { _, year, month, day ->
                    val bulan = arrayOf(
                        "Januari", "Februari", "Maret", "April", "Mei", "Juni",
                        "Juli", "Agustus", "September", "Oktober", "November", "Desember"
                    )
                    binding.tvTanggal.text = "$day ${bulan[month]} $year"
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        // TimePickerDialog
        binding.btnTimePicker.setOnClickListener {
            val calendar = Calendar.getInstance()
            TimePickerDialog(
                this,
                { _, hour, minute ->
                    val jam = String.format("%02d", hour)
                    val menit = String.format("%02d", minute)
                    binding.tvWaktu.text = "$jam:$menit WIB"
                },
                calendar.get(Calendar.HOUR_OF_DAY),
                calendar.get(Calendar.MINUTE),
                true
            ).show()
        }

        // AlertDialog standar
        binding.btnAlertDialog.setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("Konfirmasi")
                .setMessage("Apakah Anda yakin ingin melanjutkan?")
                .setNegativeButton("Batal") { dialog, _ ->
                    dialog.dismiss()
                }
                .setPositiveButton("Ya, Lanjutkan") { _, _ ->
                    MaterialAlertDialogBuilder(this)
                        .setTitle("Sukses")
                        .setMessage("Aksi berhasil dikonfirmasi!")
                        .setPositiveButton("OK", null)
                        .show()
                }
                .show()
        }

        // Custom Dialog
        binding.btnCustomDialog.setOnClickListener {
            showCustomDialog()
        }
    }

    private fun showCustomDialog() {
        val dialogView = LayoutInflater.from(this).inflate(android.R.layout.select_dialog_item, null)
        // Kita buat custom dialog dengan layout sederhana via builder
        MaterialAlertDialogBuilder(this)
            .setTitle("Informasi Aplikasi")
            .setMessage(
                "Aplikasi ini dibuat untuk memenuhi tugas mata kuliah Pemrograman Mobile.\n\n" +
                        "Fitur yang diimplementasikan:\n" +
                        "- Complete Form\n" +
                        "- Advanced Validation\n" +
                        "- Selection Controls\n" +
                        "- Spinner & Dialog\n" +
                        "- Gesture Interaction\n" +
                        "- GitHub Repository"
            )
            .setPositiveButton("Mengerti", null)
            .setNegativeButton("Tutup") { dialog, _ -> dialog.dismiss() }
            .setNeutralButton("Tentang") { _, _ ->
                MaterialAlertDialogBuilder(this)
                    .setTitle("Tentang")
                    .setMessage("Versi 1.0\nDibuat dengan Kotlin & Material Design 3")
                    .setPositiveButton("OK", null)
                    .show()
            }
            .show()
    }
}