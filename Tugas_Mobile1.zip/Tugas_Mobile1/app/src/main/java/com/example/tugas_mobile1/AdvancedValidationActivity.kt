package com.tugas.pemrogramanmobile

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.tugas.pemrogramanmobile.databinding.ActivityAdvancedValidationBinding

class AdvancedValidationActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAdvancedValidationBinding

    // Status validasi setiap field
    private var isNamaValid = false
    private var isEmailValid = false
    private var isPasswordValid = false
    private var isKonfirmasiValid = false
    private var isTeleponValid = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAdvancedValidationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { finish() }

        setupTextWatchers()
        updateSubmitButton()
    }

    private fun setupTextWatchers() {
        // Validasi Nama (min 3 karakter)
        binding.etNama.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val text = s.toString().trim()
                isNamaValid = text.length >= 3
                binding.tilNama.error = if (!isNamaValid && text.isNotEmpty()) "Minimal 3 karakter" else null
                binding.tilNama.errorIconDrawable = null
                updateSubmitButton()
            }
        })

        // Validasi Email (format email)
        binding.etEmail.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val text = s.toString().trim()
                val emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+"
                isEmailValid = text.matches(Regex(emailPattern))
                binding.tilEmail.error = if (!isEmailValid && text.isNotEmpty()) "Format email tidak valid" else null
                binding.tilEmail.errorIconDrawable = null
                updateSubmitButton()
            }
        })

        // Validasi Password + Strength Indicator
        binding.etPassword.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val text = s.toString()
                updatePasswordStrength(text)
                isPasswordValid = text.length >= 6
                binding.tilPassword.error = if (!isPasswordValid && text.isNotEmpty()) "Minimal 6 karakter" else null
                binding.tilPassword.errorIconDrawable = null

                // Revalidasi konfirmasi jika sudah diisi
                if (binding.etKonfirmasi.text.toString().isNotEmpty()) {
                    validateKonfirmasi()
                }
                updateSubmitButton()
            }
        })

        // Validasi Konfirmasi Password
        binding.etKonfirmasi.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                validateKonfirmasi()
                updateSubmitButton()
            }
        })

        // Validasi Telepon (format Indonesia: 08xx, min 10 digit)
        binding.etTelepon.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val text = s.toString().trim()
                val phonePattern = "^08[0-9]{8,13}$"
                isTeleponValid = text.matches(Regex(phonePattern))
                binding.tilTelepon.error = if (!isTeleponValid && text.isNotEmpty()) "Format: 08xx, min 10 digit" else null
                binding.tilTelepon.errorIconDrawable = null
                updateSubmitButton()
            }
        })
    }

    private fun validateKonfirmasi() {
        val password = binding.etPassword.text.toString()
        val konfirmasi = binding.etKonfirmasi.text.toString()
        isKonfirmasiValid = konfirmasi == password && konfirmasi.isNotEmpty()
        binding.tilKonfirmasi.error = if (!isKonfirmasiValid && konfirmasi.isNotEmpty()) "Password tidak cocok" else null
        binding.tilKonfirmasi.errorIconDrawable = null
    }

    private fun updatePasswordStrength(password: String) {
        val strength = calculateStrength(password)
        val segments = listOf(binding.seg1, binding.seg2, binding.seg3, binding.seg4)
        val greyColor = ContextCompat.getColor(this, R.color.grey_light)

        val (color, text) = when (strength) {
            0 -> greyColor to ""
            1 -> ContextCompat.getColor(this, R.color.strength_weak) to "Sangat Lemah"
            2 -> ContextCompat.getColor(this, R.color.strength_weak) to "Lemah"
            3 -> ContextCompat.getColor(this, R.color.strength_medium) to "Sedang"
            else -> ContextCompat.getColor(this, R.color.strength_strong) to "Kuat"
        }

        segments.forEachIndexed { index, view ->
            view.setBackgroundColor(if (index < strength) color else greyColor)
        }

        binding.tvStrengthText.text = text
        binding.tvStrengthText.setTextColor(if (strength == 0) greyColor else color)
    }

    private fun calculateStrength(password: String): Int {
        if (password.isEmpty()) return 0
        var score = 0
        if (password.length >= 6) score++
        if (password.length >= 8) score++
        if (password.any { it.isDigit() }) score++
        if (password.any { it.isUpperCase() } && password.any { it.isLowerCase() }) score++
        if (password.any { !it.isLetterOrDigit() }) score++
        return when {
            score <= 1 -> 1
            score <= 2 -> 2
            score <= 3 -> 3
            else -> 4
        }
    }

    private fun updateSubmitButton() {
        val allValid = isNamaValid && isEmailValid && isPasswordValid && isKonfirmasiValid && isTeleponValid
        binding.btnSubmit.isEnabled = allValid
        binding.btnSubmit.alpha = if (allValid) 1f else 0.4f
    }

    // Override agar submit button bisa diklik saat valid
    // (BtnSubmit sudah di-set enabled di updateSubmitButton)
    init {
        // Akan di-panggil setelah layout inflate
    }
}