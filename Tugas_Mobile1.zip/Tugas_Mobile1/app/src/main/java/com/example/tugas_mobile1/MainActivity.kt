package com.tugas.pemrogramanmobile

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.tugas.pemrogramanmobile.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.cardTask1.setOnClickListener {
            startActivity(Intent(this, CompleteFormActivity::class.java))
        }
        binding.cardTask2.setOnClickListener {
            startActivity(Intent(this, AdvancedValidationActivity::class.java))
        }
        binding.cardTask3.setOnClickListener {
            startActivity(Intent(this, SelectionControlsActivity::class.java))
        }
        binding.cardTask4.setOnClickListener {
            startActivity(Intent(this, SpinnerDialogActivity::class.java))
        }
        binding.cardTask5.setOnClickListener {
            startActivity(Intent(this, GestureInteractionActivity::class.java))
        }
        binding.cardTask6.setOnClickListener {
            startActivity(Intent(this, GitHubRepoActivity::class.java))
        }
    }
}