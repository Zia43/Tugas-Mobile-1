package com.tugas.pemrogramanmobile

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar
import com.tugas.pemrogramanmobile.databinding.ActivitySelectionControlsBinding

class SelectionControlsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySelectionControlsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySelectionControlsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { finish() }

        // Listener untuk semua kontrol agar ringkasan selalu update
        val checkBoxes = listOf(
            binding.cbMembaca, binding.cbOlahraga,
            binding.cbMusik, binding.cbGaming, binding.cbMemasak
        )

        checkBoxes.forEach { cb ->
            cb.setOnCheckedChangeListener { _, _ -> updateRingkasan() }
        }

        binding.rgPembayaran.setOnCheckedChangeListener { _, _ -> updateRingkasan() }
        binding.switchNotif.setOnCheckedChangeListener { _, _ -> updateRingkasan() }
        binding.switchDarkMode.setOnCheckedChangeListener { _, _ -> updateRingkasan() }
        binding.cbSetuju.setOnCheckedChangeListener { _, _ -> updateRingkasan() }
    }

    private fun updateRingkasan() {
        val sb = StringBuilder()

        // Hobi
        val hobiList = mutableListOf<String>()
        if (binding.cbMembaca.isChecked) hobiList.add("Membaca")
        if (binding.cbOlahraga.isChecked) hobiList.add("Olahraga")
        if (binding.cbMusik.isChecked) hobiList.add("Musik")
        if (binding.cbGaming.isChecked) hobiList.add("Gaming")
        if (binding.cbMemasak.isChecked) hobiList.add("Memasak")

        sb.append("Hobi: ${if (hobiList.isEmpty()) "Tidak dipilih" else hobiList.joinToString(", ")}\n")

        // Pembayaran
        val pembayaran = when (binding.rgPembayaran.checkedRadioButtonId) {
            binding.rbTransfer.id -> "Transfer Bank"
            binding.rbEwallet.id -> "E-Wallet"
            binding.rbCod.id -> "COD (Bayar di Tempat)"
            else -> "Tidak dipilih"
        }
        sb.append("Pembayaran: $pembayaran\n")

        // Switch
        sb.append("Notifikasi: ${if (binding.switchNotif.isChecked) "Aktif" else "Nonaktif"}\n")
        sb.append("Mode Gelap: ${if (binding.switchDarkMode.isChecked) "Aktif" else "Nonaktif"}\n")

        // Setuju
        sb.append("Setuju Syarat: ${if (binding.cbSetuju.isChecked) "Ya" else "Tidak"}")

        binding.tvRingkasan.text = sb.toString()

        // Snackbar jika centang syarat
        if (binding.cbSetuju.isChecked) {
            Snackbar.make(binding.root, "Anda menyetujui syarat dan ketentuan", Snackbar.LENGTH_SHORT).show()
        }
    }
}