package com.tugas.pemrogramanmobile

import android.app.DatePickerDialog
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.tugas.pemrogramanmobile.databinding.ActivityCompleteFormBinding
import java.util.Calendar

class CompleteFormActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCompleteFormBinding
    private var selectedDate = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCompleteFormBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { finish() }

        // DatePicker untuk Tanggal Lahir
        binding.etTanggalLahir.setOnClickListener { showDatePicker() }

        // Submit
        binding.btnSubmit.setOnClickListener { submitForm() }
    }

    private fun showDatePicker() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        DatePickerDialog(
            this,
            { _, y, m, d ->
                selectedDate = "$d/${m + 1}/$y"
                binding.etTanggalLahir.setText(selectedDate)
            },
            year, month, day
        ).show()
    }

    private fun submitForm() {
        val nama = binding.etNama.text.toString().trim()
        val email = binding.etEmail.text.toString().trim()
        val password = binding.etPassword.text.toString().trim()
        val telepon = binding.etTelepon.text.toString().trim()
        val tanggalLahir = binding.etTanggalLahir.text.toString().trim()
        val alamat = binding.etAlamat.text.toString().trim()

        // Ambil jenis kelamin dari RadioGroup
        val selectedGenderId = binding.rgJenisKelamin.checkedRadioButtonId
        val jenisKelamin = when (selectedGenderId) {
            binding.rbLaki.id -> "Laki-laki"
            binding.rbPerempuan.id -> "Perempuan"
            else -> "Belum dipilih"
        }

        // Validasi sederhana
        if (nama.isEmpty() || email.isEmpty() || password.isEmpty() || telepon.isEmpty() ||
            tanggalLahir.isEmpty() || alamat.isEmpty() || selectedGenderId == -1
        ) {
            MaterialAlertDialogBuilder(this)
                .setTitle("Perhatian")
                .setMessage("Semua field wajib diisi!")
                .setPositiveButton("OK", null)
                .show()
            return
        }

        // Tampilkan hasil di AlertDialog
        val message = """
            |Nama: $nama
            |Email: $email
            |Password: ${"*".repeat(password.length)}
            |Telepon: $telepon
            |Tanggal Lahir: $tanggalLahir
            |Jenis Kelamin: $jenisKelamin
            |Alamat: $alamat
        """.trimMargin()

        MaterialAlertDialogBuilder(this)
            .setTitle("Data Pendaftaran")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }
}