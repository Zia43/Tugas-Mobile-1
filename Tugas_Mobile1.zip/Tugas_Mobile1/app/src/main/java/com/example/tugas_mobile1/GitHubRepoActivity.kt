package com.tugas.pemrogramanmobile

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.tugas.pemrogramanmobile.databinding.ActivityGithubRepoBinding

class GitHubRepoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGithubRepoBinding

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGithubRepoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { finish() }

        // Konfigurasi WebView
        binding.webView.settings.javaScriptEnabled = true
        binding.webView.settings.domStorageEnabled = true
        binding.webView.settings.setSupportZoom(true)
        binding.webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                view?.loadUrl(url ?: "")
                return true
            }
        }

        binding.webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (newProgress == 100) {
                    binding.progressBar.visibility = View.GONE
                    binding.webView.visibility = View.VISIBLE
                } else {
                    binding.progressBar.visibility = View.VISIBLE
                    binding.webView.visibility = View.GONE
                }
            }
        }

        // Tombol Load URL
        binding.btnLoad.setOnClickListener {
            loadUrl()
        }

        // Enter pada EditText juga memuat URL
        binding.etUrl.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_UP) {
                loadUrl()
                true
            } else {
                false
            }
        }

        // Load default URL
        loadUrl()
    }

    private fun loadUrl() {
        var url = binding.etUrl.text.toString().trim()
        if (url.isEmpty()) {
            url = "https://github.com"
        }
        // Tambahkan https jika belum ada
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "https://$url"
        }
        binding.etUrl.setText(url)
        binding.webView.loadUrl(url)
    }

    // Handle tombol Back untuk navigasi WebView
    override fun onBackPressed() {
        if (binding.webView.canGoBack()) {
            binding.webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}