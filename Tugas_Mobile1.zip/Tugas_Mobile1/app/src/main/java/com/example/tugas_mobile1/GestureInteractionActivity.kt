package com.tugas.pemrogramanmobile

import android.animation.ObjectAnimator
import android.graphics.Color
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.tugas.pemrogramanmobile.databinding.ActivityGestureInteractionBinding

class GestureInteractionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGestureInteractionBinding
    private var currentScale = 1f

    private companion object {
        const val SWIPE_THRESHOLD = 100
        const val SWIPE_VELOCITY_THRESHOLD = 100
    }

    private val gestureDetector by lazy {
        GestureDetectorCompat(this, object : GestureDetector.SimpleOnGestureListener() {

            override fun onSingleTapUp(e: MotionEvent): Boolean {
                onGestureDetected("Single Tap", R.color.gesture_tap)
                // Animasi pulse
                animatePulse()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                onGestureDetected("Double Tap", R.color.gesture_double)
                // Animasi scale up lalu kembali
                animateScale(1.3f, 300)
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                onGestureDetected("Long Press", R.color.gesture_long)
                animateScale(0.9f, 500)
            }

            override fun onFling(
                e1: MotionEvent?,
                e2: MotionEvent,
                velocityX: Float,
                velocityY: Float
            ): Boolean {
                val diffX = e2.x - (e1?.x ?: 0f)
                val diffY = e2.y - (e1?.y ?: 0f)

                if (Math.abs(diffX) > Math.abs(diffY)) {
                    if (Math.abs(diffX) > SWIPE_THRESHOLD && Math.abs(velocityX) > SWIPE_VELOCITY_THRESHOLD) {
                        if (diffX > 0) {
                            onGestureDetected("Swipe Right", R.color.gesture_swipe)
                            animateTranslation(200f, 0f)
                        } else {
                            onGestureDetected("Swipe Left", R.color.gesture_swipe)
                            animateTranslation(-200f, 0f)
                        }
                        return true
                    }
                } else {
                    if (Math.abs(diffY) > SWIPE_THRESHOLD && Math.abs(velocityY) > SWIPE_VELOCITY_THRESHOLD) {
                        if (diffY > 0) {
                            onGestureDetected("Swipe Down", R.color.gesture_swipe)
                            animateTranslation(0f, 200f)
                        } else {
                            onGestureDetected("Swipe Up", R.color.gesture_swipe)
                            animateTranslation(0f, -200f)
                        }
                        return true
                    }
                }
                return false
            }

            override fun onDown(e: MotionEvent): Boolean = true
        })
    }

    private val scaleDetector by lazy {
        android.view.ScaleGestureDetector(this, object : android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: android.view.ScaleGestureDetector): Boolean {
                currentScale *= detector.scaleFactor
                currentScale = currentScale.coerceIn(0.5f, 2.5f)
                binding.gestureBox.scaleX = currentScale
                binding.gestureBox.scaleY = currentScale
                return true
            }

            override fun onScaleEnd(detector: android.view.ScaleGestureDetector) {
                onGestureDetected("Pinch (Scale: ${String.format("%.1f", currentScale)})", R.color.gesture_pinch)
                // Kembalikan scale perlahan
                animateScale(1f, 400)
            }
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGestureInteractionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { finish() }

        // Set touch listener pada kotak gesture
        binding.gestureBox.setOnTouchListener { _, event ->
            gestureDetector.onTouchEvent(event)
            scaleDetector.onTouchEvent(event)
            true
        }
    }

    private fun onGestureDetected(gestureName: String, colorRes: Int) {
        binding.tvGestureResult.text = "Terdeteksi: $gestureName"
        binding.gestureBox.setBackgroundColor(
            ContextCompat.getColor(this, colorRes)
        )

        // Kembalikan warna setelah 800ms
        binding.gestureBox.postDelayed({
            binding.gestureBox.setBackgroundColor(
                ContextCompat.getColor(this, R.color.gesture_default)
            )
        }, 800)
    }

    private fun animatePulse() {
        val scaleX = ObjectAnimator.ofFloat(binding.gestureBox, "scaleX", 1f, 1.15f, 1f)
        val scaleY = ObjectAnimator.ofFloat(binding.gestureBox, "scaleY", 1f, 1.15f, 1f)
        scaleX.duration = 300
        scaleY.duration = 300
        scaleX.start()
        scaleY.start()
    }

    private fun animateScale(targetScale: Float, duration: Long) {
        val scaleX = ObjectAnimator.ofFloat(binding.gestureBox, "scaleX", targetScale, 1f)
        val scaleY = ObjectAnimator.ofFloat(binding.gestureBox, "scaleY", targetScale, 1f)
        scaleX.duration = duration
        scaleY.duration = duration
        scaleX.start()
        scaleY.start()
        currentScale = 1f
    }

    private fun animateTranslation(dx: Float, dy: Float) {
        val animX = ObjectAnimator.ofFloat(binding.gestureBox, "translationX", dx, 0f)
        val animY = ObjectAnimator.ofFloat(binding.gestureBox, "translationY", dy, 0f)
        animX.duration = 400
        animY.duration = 400
        animX.start()
        animY.start()
    }
}